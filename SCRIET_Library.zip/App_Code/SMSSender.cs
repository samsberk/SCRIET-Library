﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net;

/// <summary>
/// Summary description for SMSSender
/// </summary>
public class SMSSender
{
    /*string mysenderid, myuserid, myscode;
    public SMSSender()
    {
        mysenderid = "SPILKO";
        myuserid = "BRIJESH";
        myscode = "8620e45a26XX";

    }
    public bool sendsms(string mobno, string msg)
    {
        string api = "http://sms.bulkssms.com/submitsms.jsp?user=" + myuserid + "&key=" + myscode + "&mobile=" + mobno + "&message=" + msg + "&senderid=" + mysenderid + "&accusage=1";
        WebClient wc = new WebClient();
        try
        {
            wc.DownloadString(api);
            return true;
        }
        catch
        {
            return false;
        }
    }*/
}